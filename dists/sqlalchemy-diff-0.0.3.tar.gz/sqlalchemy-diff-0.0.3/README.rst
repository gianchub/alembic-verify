SQLAlchemy Diff
===============

.. pull-quote::

    Compare and generate a diff between two databases using SQLAlchemy's
    inspection API.

Documentation here: (link to read the docs)

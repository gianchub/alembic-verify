# -*- coding: utf-8 -*-

from .comparer import compare


__all__ = ['compare']
